﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-1HVDQ0J\SQLEXPRESS;Database=MySpecialApp;Integrated Security=true;";
    }
}
