﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01InitialSetup
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-1HVDQ0J\SQLEXPRESS;Database=MinionsDB;Integrated Security=True";
    }
}
