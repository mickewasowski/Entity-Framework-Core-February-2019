﻿namespace ProductShop
{
    using AutoMapper;

    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
        }
    }
}
