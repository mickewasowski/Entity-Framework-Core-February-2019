﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-1HVDQ0J\SQLEXPRESS;Database=Hospital;Integrated Security=true;";
    }
}
