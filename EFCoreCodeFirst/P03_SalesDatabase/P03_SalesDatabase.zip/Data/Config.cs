﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-1HVDQ0J\SQLEXPRESS;Database=Store;Integrated Security=true;";
    }
}
